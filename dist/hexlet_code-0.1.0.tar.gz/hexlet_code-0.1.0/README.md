### Hexlet tests and linter status:
[![Actions Status](https://github.com/DimonDimasik/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DimonDimasik/python-project-49/actions)
<a href="https://codeclimate.com/github/DimonDimasik/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/86184d5727f28ce865bc/maintainability" /></a>



[example of win](https://asciinema.org/a/KmtQLzXmeqKbqGeCr55japq8K)

[example of loss](https://asciinema.org/a/K4tWDs6jJ6jhe3aSsnCl4Noc2)

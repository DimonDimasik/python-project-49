#!/usr/bin/env python3


from brain_games.games.progress_log import brain_progress


def main():
    brain_progress()


if __name__ == '__main__':
    main()

#!/usr/bin/env python3


from brain_games.games.prime_log import brain_prime


def main():
    brain_prime()


if __name__ == '__main__':
    main()
